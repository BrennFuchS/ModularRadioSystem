This Folder represents your channel, here you will be adding all your audio tracks for songs and (Optionaly) ads

The name of your Custom Radio Station must be the length of 10 characters or shorter.
The frequency of your station must be in the range of 75.0 - 92.5

it should look something like this: ExampleFM,78.5
the comma (,) is seperating the Channel Name from the Channel Frequency
Format: Name,Frequency

The ads.txt file is Optional and can be deleted,
it is used to declare the ads of your station

if you choose to add ads, follow these rules:
the file must contain the names of the tracks along with the extension of the file.

The Layout must be: (the order of the tracks doesn't matter)
BuildKidsShouldBeGone.mp3
OgygiaVlogsIsRetarded.wav
RadexIsACunt.ogg